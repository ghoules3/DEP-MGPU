-- Топ-5 штатов по суммарным продажам
select
  g.state,
  sum(f.sales) as total_sales,
  count(distinct f.order_id) as number_of_orders
from {{ ref('sales_fact') }} as f
left join {{ ref('geo_dim') }} as g
  on f.geo_id = g.geo_id
where g.state is not null
group by g.state
order by total_sales desc, state asc
limit 5